package dev.chickenking;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.*;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.passive.ChickenEntity;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.nio.file.*;
import java.io.*;
import java.util.*;

public final class ChickenKing implements ModInitializer {
    private static final Logger LOG = LoggerFactory.getLogger("chickenking");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String[] LAWS = {
        "Запрещено бегать: спешить имеет право только Его Клювичество!",
        "Запрещено прыгать: всё воздушное пространство принадлежит королю!",
        "Запрещено держать яйцо в руке: это потенциальный наследник престола!",
        "Запрещено спать: подданные обязаны восхищаться королём круглосуточно!",
        "Запрещено бить куриц: каждая курица — дальняя родственница короля!"
    };
    private static final String[] RANTS = {
        "Я не маленькая курица. Это вы слишком высокие подданные!",
        "КУДАХ! Министерство зерна постановило: зерно вкусное!",
        "Моё правление безупречно. Кто не согласен — неправильно кудахчет!",
        "Сегодня я отменяю вторник. Даже если сегодня не вторник!",
        "Корона тяжела. Особенно когда это золотой шлем не по размеру."
    };
    private static MinecraftServer server;
    private static State state = new State();
    private static long ticks;
    private static boolean dirty;
    private static final Map<UUID, Motion> motion = new HashMap<>();

    public static final class State {
        public boolean active;
        public boolean built;
        public int x, y, z;
        public int law;
        public int untilLaw = 3600;
        public Map<String, String> owners = new HashMap<>();
        public Map<String, Prisoner> prisoners = new HashMap<>();
        public Map<String, Integer> convictions = new HashMap<>();
    }
    public static final class Prisoner {
        public String dimension;
        public double x, y, z;
        public float yaw, pitch;
        public int remaining;
        public int cell;
    }
    private record Motion(double y, boolean grounded) {}

    @Override public void onInitialize() {
        ServerLifecycleEvents.SERVER_STARTED.register(s -> {
            server = s;
            ticks = 0;
            motion.clear();
            state = new State();
            Path path = file();
            if (Files.exists(path)) {
                try (Reader reader = Files.newBufferedReader(path)) {
                    State loaded = GSON.fromJson(reader, State.class);
                    if (loaded == null || loaded.owners == null || loaded.prisoners == null
                            || loaded.convictions == null || loaded.law < 0 || loaded.law >= LAWS.length)
                        throw new IOException("Invalid chickenking state");
                    state = loaded;
                } catch (Exception e) {
                    throw new IllegalStateException("Не удалось прочитать chickenking.json. Восстановите резервную копию; файл не перезаписан.", e);
                }
            }
            dirty = false;
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> save());
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> { server = null; motion.clear(); });
        ServerTickEvents.END_SERVER_TICK.register(ChickenKing::tick);

        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (world instanceof ServerWorld && player instanceof ServerPlayerEntity p && forbidden(p, pos))
                return ActionResult.FAIL;
            return ActionResult.PASS;
        });
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, block, entity) ->
            !(player instanceof ServerPlayerEntity p) || !forbidden(p, pos));
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, block, entity) -> {
            if (state.owners.remove(key(world, pos)) != null) dirty = true;
        });
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world instanceof ServerWorld && player instanceof ServerPlayerEntity p && subject(p)) {
                if (jailed(p)) return ActionResult.FAIL;
                if (onPlaza(world, hit.getBlockPos()) || onPlaza(world, hit.getBlockPos().offset(hit.getSide()))) {
                    jail(p, "самовольное переустройство королевской площади");
                    return ActionResult.FAIL;
                }
            }
            return ActionResult.PASS;
        });
        AttackEntityCallback.EVENT.register((player, world, hand, target, hit) -> {
            if (world instanceof ServerWorld && player instanceof ServerPlayerEntity p && subject(p)) {
                if (jailed(p)) return ActionResult.FAIL;
                if (target.getCommandTags().contains("chickenking_king")) {
                    jail(p, "покушение на достоинство Его Клювичества");
                    return ActionResult.FAIL;
                }
                if (state.law == 4 && target instanceof ChickenEntity) {
                    jail(p, "оскорбление королевской родни");
                    return ActionResult.FAIL;
                }
            }
            return ActionResult.PASS;
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, environment) -> {
            dispatcher.register(CommandManager.literal("chickenking")
                .executes(ctx -> laws(ctx.getSource()))
                .then(CommandManager.literal("laws").executes(ctx -> laws(ctx.getSource())))
                .then(CommandManager.literal("status").executes(ctx -> {
                    ctx.getSource().sendFeedback(() -> Text.literal("Куриная монархия: " +
                        (state.active ? "действует" : "выключена") + ". Заключённых: " + state.prisoners.size() +
                        ". Учтено своих блоков: " + state.owners.size()), false);
                    return 1;
                }))
                .then(CommandManager.literal("start").requires(ChickenKing::admin).executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                    if (state.active) {
                        ctx.getSource().sendError(Text.literal("Куриный король уже правит!"));
                        return 0;
                    }
                    if (!state.built) buildPlaza(p);
                    state.active = true;
                    state.untilLaw = 3600;
                    dirty = true;
                    say("КУДАХ! Я объявляю куриную диктатуру! Все природные блоки — собственность короля!");
                    say("Свои поставленные блоки ломать можно. За нарушение — публичная клетка!");
                    say("Новый указ: " + LAWS[state.law]);
                    ctx.getSource().sendFeedback(() -> Text.literal("Площадь: обычный мир, " + state.x + " " + state.y + " " + state.z + ". /chickenking visit — посетить."), false);
                    save();
                    return 1;
                }))
                .then(CommandManager.literal("stop").requires(ChickenKing::admin).executes(ctx -> {
                    state.active = false;
                    for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList())
                        if (jailed(p)) release(p);
                    // Offline prisoners retain their return position and are returned upon login.
                    dirty = true;
                    say("Куриная диктатура приостановлена. Король ушёл считать зёрнышки.");
                    save();
                    return 1;
                }))
                .then(CommandManager.literal("pardon").requires(ChickenKing::admin)
                    .executes(ctx -> {
                        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                        release(p); save(); return 1;
                    })
                    .then(CommandManager.argument("player", StringArgumentType.word()).suggests((ctx,b) -> {
                        for (String name : ctx.getSource().getServer().getPlayerNames()) b.suggest(name);
                        return b.buildFuture();
                    }).executes(ctx -> {
                        ServerPlayerEntity p = server.getPlayerManager().getPlayer(StringArgumentType.getString(ctx, "player"));
                        if (p == null) { ctx.getSource().sendError(Text.literal("Игрок должен быть в сети.")); return 0; }
                        release(p); save(); return 1;
                    })))
                .then(CommandManager.literal("visit").executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                    if (!state.built || jailed(p)) return 0;
                    tp(p, "minecraft:overworld", state.x + .5, state.y + 1.1, state.z - 11.5, 0, 0);
                    return 1;
                }))
            );
        });
    }

    // Reuse vanilla's setblock permission predicate (compatible with 1.21.11's new permissions).
    private static boolean admin(ServerCommandSource source) {
        var node = source.getServer().getCommandManager().getDispatcher().getRoot().getChild("setblock");
        return node != null && node.canUse(source);
    }
    private static int laws(ServerCommandSource source) {
        source.sendFeedback(() -> Text.literal("§6Указы Его Клювичества:\n§e1. Блоки мира и чужие постройки ломать нельзя. Свои можно.\n2. Короля бить нельзя; площадь неприкосновенна.\n3. " + LAWS[state.law] +
            "\n§7Динамический указ меняется раз в 3 минуты. Клетка: 25–60 секунд.\nСейчас монархия " + (state.active ? "действует." : "выключена.")), false);
        return 1;
    }
    private static boolean subject(ServerPlayerEntity p) {
        return state.active && !p.isCreative() && !p.isSpectator();
    }
    private static boolean jailed(ServerPlayerEntity p) { return state.prisoners.containsKey(p.getUuidAsString()); }
    private static String key(World world, BlockPos pos) {
        return world.getRegistryKey().getValue() + ":" + pos.asLong();
    }
    public static void own(ServerWorld world, BlockPos pos, ServerPlayerEntity player) {
        if (server == null || onPlaza(world, pos)) return;
        state.owners.put(key(world, pos), player.getUuidAsString());
        dirty = true;
    }
    private static boolean onPlaza(World world, BlockPos pos) {
        return state.built && world.getRegistryKey().equals(World.OVERWORLD)
            && Math.abs(pos.getX() - state.x) <= 13 && Math.abs(pos.getZ() - state.z) <= 12
            && pos.getY() >= state.y && pos.getY() <= state.y + 8;
    }
    private static boolean forbidden(ServerPlayerEntity p, BlockPos pos) {
        if (!subject(p)) return false;
        if (jailed(p)) return true;
        if (onPlaza(world(p), pos)) {
            jail(p, "попытка разобрать королевскую площадь");
            return true;
        }
        if (!p.getUuidAsString().equals(state.owners.get(key(world(p), pos)))) {
            p.sendMessage(Text.literal("§cЭти блоки принадлежат королю! §eСвои поставленные блоки ломать можно."), false);
            jail(p, "незаконная добыча королевской собственности");
            return true;
        }
        return false;
    }
    private static ServerWorld world(ServerPlayerEntity p) { return (ServerWorld) p.getEntityWorld(); }
    private static int cx(int cell) { return state.x - 9 + (cell % 4) * 6; }
    private static int cz(int cell) { return state.z - 4 + (cell / 4) * 7; }

    private static void jail(ServerPlayerEntity p, String reason) {
        if (!state.active || jailed(p) || !p.isAlive()) return;
        Prisoner q = new Prisoner();
        q.dimension = world(p).getRegistryKey().getValue().toString();
        q.x = p.getX(); q.y = p.getY(); q.z = p.getZ(); q.yaw = p.getYaw(); q.pitch = p.getPitch();
        int convictions = state.convictions.merge(p.getUuidAsString(), 1, Integer::sum);
        q.remaining = (25 + Math.min(7, convictions - 1) * 5) * 20;
        int[] occupied = new int[8];
        for (Prisoner old : state.prisoners.values()) occupied[Math.floorMod(old.cell, 8)]++;
        q.cell = 0;
        for (int i=1;i<8;i++) if (occupied[i] < occupied[q.cell]) q.cell=i;
        state.prisoners.put(p.getUuidAsString(), q);
        if (p.isSleeping()) p.wakeUp();
        p.stopRiding();
        p.setSprinting(false);
        tp(p, "minecraft:overworld", cx(q.cell) + .5, state.y + 2, cz(q.cell) + .5, 180, 0);
        say("Публичный суд! " + p.getName().getString() + ": " + reason + ". Приговор: " + q.remaining / 20 + " секунд в клетке перед народом!");
        dirty = true;
        save();
    }
    private static void release(ServerPlayerEntity p) {
        Prisoner q = state.prisoners.remove(p.getUuidAsString());
        if (q == null) return;
        tp(p, q.dimension, q.x, q.y, q.z, q.yaw, q.pitch);
        p.sendMessage(Text.literal("§aВы свободны. Король великодушно разрешает вам продолжать существовать!"), false);
        motion.remove(p.getUuid());
        dirty = true;
    }
    private static void tick(MinecraftServer s) {
        if (server == null) return;
        ticks++;
        if (state.active) {
            if (--state.untilLaw <= 0) {
                state.law = (state.law + 1) % LAWS.length;
                state.untilLaw = 3600;
                say("Новый безумный указ: " + LAWS[state.law]);
                dirty = true;
            }
            if (ticks % 900 == 0) say(RANTS[(int)((ticks / 900) % RANTS.length)]);
        }
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
            Prisoner q = state.prisoners.get(p.getUuidAsString());
            if (q != null) {
                if (!state.active || q.remaining <= 0 || p.isCreative() || p.isSpectator()) { release(p); continue; }
                if (!p.isAlive()) continue;
                q.remaining--;
                dirty = true;
                if (!world(p).getRegistryKey().equals(World.OVERWORLD)
                    || Math.abs(p.getX() - (cx(q.cell) + .5)) > 1.25
                    || Math.abs(p.getZ() - (cz(q.cell) + .5)) > 1.25
                    || p.getY() < state.y + 1.5 || p.getY() > state.y + 4.7) {
                    p.stopRiding();
                    tp(p, "minecraft:overworld", cx(q.cell) + .5, state.y + 2, cz(q.cell) + .5, 180, 0);
                }
                if (ticks % 20 == 0) p.sendMessage(Text.literal("§6Клетка позора: §f" + ((q.remaining + 19)/20) + " сек. §7Народ наблюдает."), true);
                continue;
            }
            Motion previous = motion.put(p.getUuid(), new Motion(p.getY(), p.isOnGround()));
            if (!subject(p) || !p.isAlive()) continue;
            switch (state.law) {
                case 0 -> { if (p.isSprinting()) jail(p, "слишком торопливое передвижение"); }
                case 1 -> {
                    if (previous != null && previous.grounded() && !p.isOnGround()
                        && p.getY()-previous.y() > .1 && p.getY()-previous.y() < 1
                        && !p.isTouchingWater() && !p.isClimbing() && !p.getAbilities().flying)
                        jail(p, "самовольное использование королевского воздуха");
                }
                case 2 -> {
                    if (p.getMainHandStack().isOf(Items.EGG) || p.getOffHandStack().isOf(Items.EGG))
                        jail(p, "удержание потенциального наследника престола");
                }
                case 3 -> { if (p.isSleeping()) jail(p, "сон вместо восхищения королём"); }
                default -> {}
            }
        }
        if (ticks % 600 == 0) {
            motion.keySet().removeIf(uuid -> s.getPlayerManager().getPlayer(uuid) == null);
            if (dirty) save();
        }
    }
    private static void say(String message) {
        if (server != null) server.getPlayerManager().broadcast(Text.literal("§6[Его Клювичество] §f" + message), false);
    }
    private static void command(String command) {
        server.getCommandManager().executeWithPrefix(server.getCommandSource().withSilent(), command);
    }
    private static void tp(ServerPlayerEntity p, String dimension, double x, double y, double z, float yaw, float pitch) {
        command(String.format(Locale.ROOT, "execute in %s run teleport %s %.4f %.4f %.4f %.3f %.3f", dimension,
            p.getName().getString(), x, y, z, yaw, pitch));
    }
    private static void block(ServerWorld w, int x, int y, int z, BlockState b) {
        w.setBlockState(new BlockPos(x,y,z), b, 3);
    }
    private static void buildPlaza(ServerPlayerEntity p) {
        ServerWorld w = server.getOverworld();
        state.x = p.getBlockX() + 32;
        state.z = p.getBlockZ();
        state.y = w.getBottomY() + w.getHeight() - 20;
        state.built = true;
        // This is an explicit admin action. The reserved high-altitude volume is cleared.
        for (int x=-13;x<=13;x++) for(int z=-12;z<=12;z++) {
            block(w,state.x+x,state.y,state.z+z, ((x+z)&1)==0 ? Blocks.SMOOTH_QUARTZ.getDefaultState() : Blocks.POLISHED_ANDESITE.getDefaultState());
            for(int y=1;y<=8;y++) block(w,state.x+x,state.y+y,state.z+z,Blocks.AIR.getDefaultState());
            if (Math.abs(x)==13 || Math.abs(z)==12)
                block(w,state.x+x,state.y+1,state.z+z,Blocks.GLASS_PANE.getDefaultState());
        }
        for(int cell=0;cell<8;cell++) for(int x=-2;x<=2;x++) for(int z=-2;z<=2;z++) {
            block(w,cx(cell)+x,state.y+1,cz(cell)+z,Blocks.STONE_BRICKS.getDefaultState());
            block(w,cx(cell)+x,state.y+6,cz(cell)+z,Blocks.IRON_BARS.getDefaultState());
            if(Math.abs(x)==2 || Math.abs(z)==2) for(int y=2;y<=5;y++)
                block(w,cx(cell)+x,state.y+y,cz(cell)+z,Blocks.IRON_BARS.getDefaultState());
        }
        for(int x=-2;x<=2;x++) for(int z=8;z<=10;z++)
            block(w,state.x+x,state.y+1,state.z+z,Blocks.GOLD_BLOCK.getDefaultState());
        String at = (state.x+.5)+" "+(state.y+2)+" "+(state.z+9.5);
        command("execute in minecraft:overworld run summon minecraft:chicken " + at +
            " {Tags:[\"chickenking_king\"],CustomName:{text:\"Его Клювичество\",color:\"gold\"},CustomNameVisible:1b,PersistenceRequired:1b,Invulnerable:1b,NoAI:1b,Glowing:1b}");
        command("execute in minecraft:overworld run attribute @e[tag=chickenking_king,limit=1] minecraft:scale base set 2.4");
        command("execute in minecraft:overworld run summon minecraft:text_display " + (state.x+.5)+" "+(state.y+5)+" "+(state.z+9.5)+
            " {Tags:[\"chickenking_decor\"],billboard:\"center\",text:{text:\"♛ КУРИНЫЙ КОРОЛЬ ♛\",color:\"gold\",bold:true},background:0}");
        for(int i=0;i<10;i++) {
            int x=state.x-10+i*2;
            command("execute in minecraft:overworld run summon minecraft:villager " +(x+.5)+" "+(state.y+1)+" "+(state.z-9.5)+
                " {Tags:[\"chickenking_crowd\"],CustomName:{text:\"Зритель\"},PersistenceRequired:1b,Invulnerable:1b,NoAI:1b,Silent:1b,Rotation:[0f,0f]}");
        }
        dirty=true;
    }
    private static Path file() { return server.getSavePath(WorldSavePath.ROOT).resolve("chickenking.json"); }
    private static void save() {
        if (server == null) return;
        try {
            Path path=file(), temp=path.resolveSibling("chickenking.json.tmp");
            try (Writer writer=Files.newBufferedWriter(temp)) { GSON.toJson(state,writer); }
            if(Files.exists(path)) Files.copy(path,path.resolveSibling("chickenking.json.bak"),StandardCopyOption.REPLACE_EXISTING);
            try { Files.move(temp,path,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE); }
            catch(AtomicMoveNotSupportedException e) { Files.move(temp,path,StandardCopyOption.REPLACE_EXISTING); }
            dirty=false;
        } catch(IOException e) { LOG.error("Не удалось сохранить куриное королевство",e); }
    }
}
