package dev.chickenking.mixin;

import dev.chickenking.ChickenKing;
import net.minecraft.block.BlockState;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import java.util.*;

@Mixin(BlockItem.class)
public abstract class BlockItemMixin {
    @Unique private static final ThreadLocal<Deque<Snapshot>> chickenking$snapshots = ThreadLocal.withInitial(ArrayDeque::new);
    @Unique private static final class Snapshot {
        final Map<BlockPos, BlockState> before = new HashMap<>();
        ServerWorld world;
        ServerPlayerEntity player;
    }
    @Inject(method="place(Lnet/minecraft/item/ItemPlacementContext;)Lnet/minecraft/util/ActionResult;", at=@At("HEAD"))
    private void chickenking$before(ItemPlacementContext context, CallbackInfoReturnable<ActionResult> cir) {
        Snapshot s=new Snapshot();
        if(context.getWorld() instanceof ServerWorld world && context.getPlayer() instanceof ServerPlayerEntity player) {
            s.world=world; s.player=player;
            BlockPos origin=context.getBlockPos();
            // Capture multi-block placements, including beds and the upper halves of doors.
            for(int x=-1;x<=1;x++) for(int y=-1;y<=1;y++) for(int z=-1;z<=1;z++) {
                BlockPos pos=origin.add(x,y,z);
                s.before.put(pos,world.getBlockState(pos));
            }
        }
        chickenking$snapshots.get().push(s);
    }
    @Inject(method="place(Lnet/minecraft/item/ItemPlacementContext;)Lnet/minecraft/util/ActionResult;", at=@At("RETURN"))
    private void chickenking$after(ItemPlacementContext context, CallbackInfoReturnable<ActionResult> cir) {
        Deque<Snapshot> stack=chickenking$snapshots.get();
        if(stack.isEmpty()) return;
        Snapshot s=stack.pop();
        if(stack.isEmpty()) chickenking$snapshots.remove();
        if(s.world==null || !cir.getReturnValue().isAccepted()) return;
        for(var entry:s.before.entrySet()) {
            BlockState before=entry.getValue(), after=s.world.getBlockState(entry.getKey());
            if((before.isAir() || before.isReplaceable()) && !after.isAir() && before.getBlock()!=after.getBlock())
                ChickenKing.own(s.world,entry.getKey(),s.player);
        }
    }
}
